const PLUGIN_ID = "com.raad.androidsharebridge";

function guessMime(name) {
  const ext = String(name || "").toLowerCase().split(".").pop();
  const types = {
    html:"text/html", htm:"text/html", css:"text/css",
    js:"text/javascript", mjs:"text/javascript",
    json:"application/json", txt:"text/plain", pdf:"application/pdf",
    jpg:"image/jpeg", jpeg:"image/jpeg", png:"image/png",
    webp:"image/webp", gif:"image/gif", mp4:"video/mp4",
    mp3:"audio/mpeg", wav:"audio/wav", zip:"application/zip",
    apk:"application/vnd.android.package-archive"
  };
  return types[ext] || "application/octet-stream";
}

function shareCurrentFile() {
  const file = editorManager.activeFile;
  if (!file) {
    acode.alert("Android Share Bridge", "افتح ملفًا أولًا.");
    return;
  }
  if (!window.system || typeof system.fileAction !== "function") {
    acode.alert("Android Share Bridge", "Android System API غير متاح في إصدار Acode الحالي.");
    return;
  }

  system.fileAction(
    file.uri,
    file.filename || file.name || "file",
    "SEND",
    guessMime(file.filename || file.name || ""),
    (error) => {
      if (error) acode.alert("فشل المشاركة", String(error));
    }
  );
}

if (window.acode) {
  acode.setPluginInit(PLUGIN_ID, async () => {
    const commands = acode.require("commands");
    commands.addCommand({
      name: "android-share-bridge.share-current-file",
      description: "Android: Share current file",
      exec: shareCurrentFile
    });
  });

  acode.setPluginUnmount(PLUGIN_ID, () => {
    try {
      const commands = acode.require("commands");
      commands.removeCommand("android-share-bridge.share-current-file");
    } catch (e) {}
  });
}
