# Android Share Bridge
افتح ملفًا في Acode ثم افتح Command Palette واختر:
Android: Share current file
سيتم فتح نافذة مشاركة Android الأصلية.
